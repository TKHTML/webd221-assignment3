var previousScroll = 0,
    headerOrgOffset = $('nav').height();

$('nav').height($('nav').height());

$(window).scroll(function () {
    var currentScroll = $(this).scrollTop();
    if (currentScroll > headerOrgOffset) {
        if (currentScroll > previousScroll) {
            $('nav').slideUp();
        } else {
            $('nav').slideDown();
        }
    } 
    previousScroll = currentScroll;
});